/* A Bison parser, made by GNU Bison 3.7.6.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_CAMI_CAMI_YACC_HXX_INCLUDED
# define YY_CAMI_CAMI_YACC_HXX_INCLUDED
/* Debug traces.  */
#ifndef CAMIDEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define CAMIDEBUG 1
#  else
#   define CAMIDEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define CAMIDEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined CAMIDEBUG */
#if CAMIDEBUG
extern int Camidebug;
#endif

/* Token kinds.  */
#ifndef CAMITOKENTYPE
# define CAMITOKENTYPE
  enum Camitokentype
  {
    CAMIEMPTY = -2,
    CAMIEOF = 0,                   /* "end of file"  */
    CAMIerror = 256,               /* error  */
    CAMIUNDEF = 257,               /* "invalid token"  */
    IDENT = 258,                   /* IDENT  */
    DENT = 259,                    /* DENT  */
    ENTIER = 260,                  /* ENTIER  */
    ESPACE = 261,                  /* ESPACE  */
    DB = 262,                      /* DB  */
    FB = 263,                      /* FB  */
    CA = 264,                      /* CA  */
    CT = 265,                      /* CT  */
    CN = 266,                      /* CN  */
    CM = 267,                      /* CM  */
    CP = 268,                      /* CP  */
    LOSS = 269,                    /* LOSS  */
    COMMENTAIRE = 270,             /* COMMENTAIRE  */
    PO = 271,                      /* PO  */
    PT = 272,                      /* PT  */
    PI = 273,                      /* PI  */
    NET = 274,                     /* NET  */
    PLACE = 275,                   /* PLACE  */
    QUEUE = 276,                   /* QUEUE  */
    TRANSITION = 277,              /* TRANSITION  */
    IMMEDIATE = 278,               /* IMMEDIATE  */
    NAME = 279,                    /* NAME  */
    DECLARATION = 280,             /* DECLARATION  */
    AUTHORS = 281,                 /* AUTHORS  */
    CAMIVERSION = 282,             /* CAMIVERSION  */
    TITLE = 283,                   /* TITLE  */
    PROJECT = 284,                 /* PROJECT  */
    DATE = 285,                    /* DATE  */
    CODE = 286,                    /* CODE  */
    DOMAINE = 287,                 /* DOMAINE  */
    COMPONENT = 288,               /* COMPONENT  */
    GUARD = 289,                   /* GUARD  */
    PRIORITY = 290,                /* PRIORITY  */
    DELAY = 291,                   /* DELAY  */
    ACTION = 292,                  /* ACTION  */
    WEIGHT = 293,                  /* WEIGHT  */
    CAPACITY = 294,                /* CAPACITY  */
    VALUATION = 295,               /* VALUATION  */
    MARKING = 296,                 /* MARKING  */
    ARC = 297,                     /* ARC  */
    INHIBITOR = 298                /* INHIBITOR  */
  };
  typedef enum Camitokentype Camitoken_kind_t;
#endif
/* Token kinds.  */
#define CAMIEMPTY -2
#define CAMIEOF 0
#define CAMIerror 256
#define CAMIUNDEF 257
#define IDENT 258
#define DENT 259
#define ENTIER 260
#define ESPACE 261
#define DB 262
#define FB 263
#define CA 264
#define CT 265
#define CN 266
#define CM 267
#define CP 268
#define LOSS 269
#define COMMENTAIRE 270
#define PO 271
#define PT 272
#define PI 273
#define NET 274
#define PLACE 275
#define QUEUE 276
#define TRANSITION 277
#define IMMEDIATE 278
#define NAME 279
#define DECLARATION 280
#define AUTHORS 281
#define CAMIVERSION 282
#define TITLE 283
#define PROJECT 284
#define DATE 285
#define CODE 286
#define DOMAINE 287
#define COMPONENT 288
#define GUARD 289
#define PRIORITY 290
#define DELAY 291
#define ACTION 292
#define WEIGHT 293
#define CAPACITY 294
#define VALUATION 295
#define MARKING 296
#define ARC 297
#define INHIBITOR 298

/* Value type.  */
#if ! defined CAMISTYPE && ! defined CAMISTYPE_IS_DECLARED
union CAMISTYPE
{
#line 75 "Cami_yacc.yxx"

   int  j;
  char *s;
  struct cami::LossCty LC;  //pour les attributs Loss et capacity

#line 167 "Cami_yacc.hxx"

};
typedef union CAMISTYPE CAMISTYPE;
# define CAMISTYPE_IS_TRIVIAL 1
# define CAMISTYPE_IS_DECLARED 1
#endif


extern CAMISTYPE Camilval;

int Camiparse (void);

#endif /* !YY_CAMI_CAMI_YACC_HXX_INCLUDED  */
